<?php 
$koneksi = mysqli_connect("localhost","mhghzmyi_liquid","Mantemand12&","mhghzmyi_kkp");
?>